﻿namespace DersOgrenci.Models
{
	public class Class
	{
		public int ClassId { get; set; }
		public int Level { get; set; }
		public string Branch { get; set; }
		public List<Student> Students { get; set; }
		public Class()
		{
			Students= new List<Student>();
		}
	}
}
