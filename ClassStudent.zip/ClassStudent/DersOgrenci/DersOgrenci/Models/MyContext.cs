﻿using Microsoft.EntityFrameworkCore;

namespace DersOgrenci.Models
{
	public class MyContext : DbContext
	{
		public MyContext(DbContextOptions options) : base(options)
		{
		}
		public DbSet<Class> Class { get; set; }
		public DbSet<Student> Student { get; set; }
	}
}
