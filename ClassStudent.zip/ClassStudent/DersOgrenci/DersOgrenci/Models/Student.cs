﻿namespace DersOgrenci.Models
{
	public class Student
	{
		public int StudentId { get; set; }
		public string FirstName { get; set; }
		public string LastName { get; set; }
		public string Adress { get; set; }
		public int ClassId { get; set; }
		public Class Classes { get; set; }


	}
}
